from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
from datetime import datetime

# Save the pipeline to a file
joblib.dump(pipeline_with_weights, 'model_pipeline.pkl')

app = Flask(__name__)

# Load the trained model pipeline
model = joblib.load('model_pipeline.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        try:
            # Get form data
            join_date = datetime.strptime(request.form['Join_Date'], '%Y-%m-%d')
            
            # Calculate Join_Year, Join_Month, Join_Day, Join_Weekday
            join_year = join_date.year
            join_month = join_date.month
            join_day = join_date.day
            join_weekday = join_date.weekday()

            # Create input data array
            input_data = [
                int(request.form['Account_Age_Days']),
                float(request.form['Monthly_Fee']),
                int(request.form['Num_Devices']),
                float(request.form['Avg_Watch_Time_per_Week']),
                int(request.form['Customer_Satisfaction']),
                int(request.form['Subscription_Plan']),
                int(request.form['Payment_Method']),
                int(request.form['Has_Discount']),
                join_year,
                join_month,
                join_day,
                join_weekday
            ]

            # Make prediction
            input_array = np.array(input_data).reshape(1, -1)
            prediction = model.predict(input_array)[0]
            prediction_prob = model.predict_proba(input_array)[0][1]

            result = {
                'prediction': 'Likely to Churn' if prediction == 1 else 'Not Likely to Churn',
                'probability': f"{prediction_prob:.2%}"
            }
            return render_template('result.html', result=result)

        except Exception as e:
            return jsonify({'error': str(e)})

    return "Invalid request method"

if __name__ == '__main__':
    app.run(debug=True)