import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import joblib

# Load your data
customer_data = pd.read_csv('C:/Users/Hp 830 i7/Desktop/churn_prediction/Netflix_updated.csv')  # Make sure this matches your CSV file name
customer_data['Join_Date'] = pd.to_datetime(customer_data['Join_Date'])

# Extract additional features from the Join_Date
customer_data['Join_Year'] = customer_data['Join_Date'].dt.year
customer_data['Join_Month'] = customer_data['Join_Date'].dt.month
customer_data['Join_Day'] = customer_data['Join_Date'].dt.day
customer_data['Join_Weekday'] = customer_data['Join_Date'].dt.weekday

# Drop the original Join_Date
customer_data = customer_data.drop('Join_Date', axis=1)

# Define features and target
features = customer_data.drop(['Churn_Status', 'Customer_ID'], axis=1)
target = customer_data['Churn_Status']

# Identify categorical and numerical features
categorical_features = ['Subscription_Plan', 'Payment_Method', 'Has_Discount', 'Join_Year', 'Join_Month', 'Join_Day', 'Join_Weekday']
numerical_features = ['Account_Age_Days', 'Monthly_Fee', 'Num_Devices', 'Avg_Watch_Time_per_Week', 'Customer_Satisfaction']

# Define the preprocessor
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ]
)

# Split the data
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42, stratify=target)

# Create the pipeline with class weights
pipeline_with_weights = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(class_weight='balanced', random_state=42))
])

# Fit the model
pipeline_with_weights.fit(X_train, y_train)

# Save the model to a file
joblib.dump(pipeline_with_weights, 'model_pipeline.pkl')
print("Model trained and saved successfully!")

# Evaluate the model
y_pred = pipeline_with_weights.predict(X_test)
print("\nModel Evaluation:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))