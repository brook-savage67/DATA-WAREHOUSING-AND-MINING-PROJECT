from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
import pandas as pd
from datetime import datetime

app = Flask(__name__)

# Load the trained model pipeline
model = joblib.load('model_pipeline.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        try:
            # Get form data
            join_date = datetime.strptime(request.form['Join_Date'], '%Y-%m-%d')
            
            # Create input data dictionary
            input_data = {
                'Account_Age_Days': int(request.form['Account_Age_Days']),
                'Monthly_Fee': float(request.form['Monthly_Fee']),
                'Num_Devices': int(request.form['Num_Devices']),
                'Avg_Watch_Time_per_Week': float(request.form['Avg_Watch_Time_per_Week']),
                'Customer_Satisfaction': int(request.form['Customer_Satisfaction']),
                'Subscription_Plan': int(request.form['Subscription_Plan']),
                'Payment_Method': int(request.form['Payment_Method']),
                'Has_Discount': int(request.form['Has_Discount']),
                'Join_Year': join_date.year,
                'Join_Month': join_date.month,
                'Join_Day': join_date.day,
                'Join_Weekday': join_date.weekday()
            }

            # Convert to DataFrame to maintain feature order
            input_df = pd.DataFrame([input_data])

            # Make prediction
            prediction = model.predict(input_df)[0]
            prediction_prob = model.predict_proba(input_df)[0][1]

            result = {
                'prediction': 'Likely to Churn' if prediction == 1 else 'Not Likely to Churn',
                'probability': f"{prediction_prob:.2%}"
            }
            return render_template(result)

        except Exception as e:
            return jsonify({'error': str(e)})

    return "Invalid request method"

if __name__ == '__main__':
    app.run(debug=True)